# ClearOut Pro 🚛
### Edmonton Junk Removal Business Management App
*A product by [MicrOrbit](https://microrbit.ca)*

---

A full-stack business management system built with **Next.js 14**, **Tailwind CSS**, and **Supabase**. Includes a customer-facing landing page, internal dashboard, Kanban job board, revenue tracker, and pricing configurator.

---

## ✨ Features

- **Landing Page** — SEO-optimised, quote form, services, pricing, reviews, FAQ
- **Dashboard** — Today's jobs, recent activity, lead source analytics
- **Job Board (Kanban)** — Drag-and-drop cards across: New → Quoted → Booked → Done → Paid
- **Quote Intake** — Add leads manually with full customer & job details
- **Revenue Tracker** — Monthly chart, completed jobs, expense logger
- **Pricing Config** — Edit service rates inline, add/remove services
- **Supabase Ready** — Full PostgreSQL schema included
- **Mobile Responsive** — Works on phone, tablet, desktop

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
# After unzipping, navigate to the folder
cd junk-removal-app

# Install dependencies
npm install
```

### 2. Set Up Environment Variables

```bash
cp .env.local.example .env.local
```

Open `.env.local` and fill in your keys (see below).

### 3. Run in Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) — you're live!

---

## 🗄️ Supabase Setup

1. Go to [supabase.com](https://supabase.com) → Create a new project
2. Go to **SQL Editor** → paste contents of `supabase-schema.sql` → Run
3. Go to **Project Settings → API** → copy your URL and anon key
4. Paste into `.env.local`

---

## 🌐 Deploy to Vercel (Free)

1. Push your code to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

2. Go to [vercel.com](https://vercel.com) → Import your GitHub repo
3. Add your environment variables in Vercel dashboard
4. Click **Deploy** — done! You get a free `.vercel.app` URL instantly

---

## 🔧 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | Next.js 14 (App Router) |
| Styling | Tailwind CSS |
| Database | Supabase (PostgreSQL) |
| Auth | Supabase Auth |
| File Storage | Supabase Storage |
| SMS | Twilio |
| Email | Resend |
| Hosting | Vercel |

---

## 📁 Project Structure

```
app/
├── page.js              → Customer landing page
├── dashboard/page.js    → Business dashboard
├── jobs/page.js         → Kanban job board
├── quotes/page.js       → Add new lead/quote
├── revenue/page.js      → Income & expense tracker
├── pricing/page.js      → Edit service pricing
└── api/quote/route.js   → Quote form API endpoint

components/
├── Navbar.js            → Internal app navigation
└── Footer.js            → Sitewide footer with MicrOrbit credit

lib/
├── supabase.js          → Supabase client
└── utils.js             → Helpers, mock data, constants
```

---

## 🔑 Environment Variables

| Variable | Where to get it |
|----------|----------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Project Settings → API |
| `TWILIO_ACCOUNT_SID` | twilio.com/console |
| `TWILIO_AUTH_TOKEN` | twilio.com/console |
| `TWILIO_PHONE_NUMBER` | Your Twilio number |
| `OWNER_PHONE_NUMBER` | Your mobile number |
| `RESEND_API_KEY` | resend.com/api-keys |

---

## 📱 Activate Real Backend

In `app/api/quote/route.js`, uncomment the Supabase, Resend, and Twilio blocks to wire up:
- Database saves
- Email notifications to you
- SMS alerts on new leads

---

## 🛣️ Roadmap

- [ ] Supabase Auth login for dashboard
- [ ] Before/After photo upload per job
- [ ] Google Review auto-text after job completion
- [ ] PDF invoice generator
- [ ] WhatsApp Business API integration
- [ ] Route optimizer (multi-job days)
- [ ] Customer portal (job status link)
- [ ] Follow-up SMS sequences (Day 1, 3, 7)

---

© 2025 ClearOut Pro. All rights reserved.  
A product by **MicrOrbit** — [microrbit.ca](https://microrbit.ca)
