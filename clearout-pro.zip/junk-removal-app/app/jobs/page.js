'use client';
import { useState } from 'react';
import { Phone, MapPin, Calendar, DollarSign, Search, Filter, Plus } from 'lucide-react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { MOCK_JOBS, formatCurrency, formatDate, STATUS_COLORS, STATUS_LABELS } from '@/lib/utils';

const COLUMNS = [
  { id: 'new', label: 'New Leads', color: 'border-blue-500' },
  { id: 'quoted', label: 'Quoted', color: 'border-yellow-500' },
  { id: 'booked', label: 'Booked', color: 'border-brand-orange' },
  { id: 'done', label: 'Completed', color: 'border-green-500' },
  { id: 'paid', label: 'Paid', color: 'border-emerald-500' },
];

export default function JobsPage() {
  const [jobs, setJobs] = useState(MOCK_JOBS);
  const [search, setSearch] = useState('');
  const [dragging, setDragging] = useState(null);
  const [dragOver, setDragOver] = useState(null);

  const filtered = jobs.filter(j =>
    j.customer_name.toLowerCase().includes(search.toLowerCase()) ||
    j.service_type.toLowerCase().includes(search.toLowerCase()) ||
    j.address.toLowerCase().includes(search.toLowerCase())
  );

  function getJobsByStatus(status) {
    return filtered.filter(j => j.status === status);
  }

  function handleDragStart(e, jobId) {
    setDragging(jobId);
    e.dataTransfer.effectAllowed = 'move';
  }

  function handleDrop(e, newStatus) {
    e.preventDefault();
    if (!dragging) return;
    setJobs(prev =>
      prev.map(j => j.id === dragging ? { ...j, status: newStatus } : j)
    );
    setDragging(null);
    setDragOver(null);
  }

  function handleStatusChange(jobId, newStatus) {
    setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status: newStatus } : j));
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display text-4xl text-white tracking-wide">JOB BOARD</h1>
            <p className="text-brand-muted text-sm mt-1">Drag cards between columns to update job status.</p>
          </div>
          <Link href="/quotes" className="btn-primary flex items-center gap-2 text-sm">
            <Plus size={16} />
            New Job
          </Link>
        </div>

        {/* Search */}
        <div className="relative mb-6 max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-muted" />
          <input
            type="text"
            placeholder="Search jobs..."
            className="input-dark pl-9"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        {/* Kanban Board */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4 pb-8">
          {COLUMNS.map(({ id, label, color }) => {
            const colJobs = getJobsByStatus(id);
            const total = colJobs.reduce((sum, j) => sum + j.price, 0);

            return (
              <div
                key={id}
                onDragOver={e => { e.preventDefault(); setDragOver(id); }}
                onDragLeave={() => setDragOver(null)}
                onDrop={e => handleDrop(e, id)}
                className={`
                  bg-brand-card/50 rounded-xl border-t-2 ${color} transition-all duration-200
                  ${dragOver === id ? 'bg-brand-orange/5 ring-2 ring-brand-orange/20' : ''}
                `}
              >
                {/* Column Header */}
                <div className="px-4 py-3 border-b border-brand-border">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-white text-sm">{label}</span>
                    <div className="flex items-center gap-1.5">
                      <span className="w-5 h-5 bg-brand-border rounded-full flex items-center justify-center text-xs text-brand-muted font-bold">
                        {colJobs.length}
                      </span>
                    </div>
                  </div>
                  {colJobs.length > 0 && (
                    <div className="text-xs text-brand-muted mt-0.5 font-medium">{formatCurrency(total)}</div>
                  )}
                </div>

                {/* Cards */}
                <div className="p-2 space-y-2 min-h-[200px]">
                  {colJobs.map((job) => (
                    <div
                      key={job.id}
                      draggable
                      onDragStart={e => handleDragStart(e, job.id)}
                      onDragEnd={() => { setDragging(null); setDragOver(null); }}
                      className={`
                        bg-brand-card border border-brand-border rounded-lg p-3 cursor-grab active:cursor-grabbing
                        hover:border-brand-orange/50 transition-all duration-200 card-hover
                        ${dragging === job.id ? 'opacity-50 scale-95' : ''}
                      `}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <span className="font-semibold text-white text-sm leading-tight">{job.customer_name}</span>
                        <span className="font-bold text-brand-orange text-sm flex-shrink-0 ml-2">
                          {formatCurrency(job.price)}
                        </span>
                      </div>

                      <div className="text-xs text-brand-muted mb-1.5 font-medium text-brand-orange/80">
                        {job.service_type}
                      </div>

                      <div className="flex items-center gap-1 text-xs text-brand-muted mb-1">
                        <MapPin size={9} className="flex-shrink-0" />
                        <span className="truncate">{job.address}</span>
                      </div>

                      <div className="flex items-center gap-1 text-xs text-brand-muted mb-3">
                        <Calendar size={9} className="flex-shrink-0" />
                        {formatDate(job.preferred_date)}
                      </div>

                      {/* Notes */}
                      {job.notes && (
                        <p className="text-xs text-brand-muted bg-brand-dark rounded p-2 mb-3 line-clamp-2">
                          {job.notes}
                        </p>
                      )}

                      {/* Quick status change */}
                      <select
                        value={job.status}
                        onChange={e => handleStatusChange(job.id, e.target.value)}
                        onClick={e => e.stopPropagation()}
                        className="w-full bg-brand-dark border border-brand-border text-xs text-brand-muted rounded px-2 py-1 focus:outline-none focus:border-brand-orange"
                      >
                        {COLUMNS.map(({ id, label }) => (
                          <option key={id} value={id}>{label}</option>
                        ))}
                      </select>
                    </div>
                  ))}

                  {colJobs.length === 0 && (
                    <div className="flex items-center justify-center h-20 border-2 border-dashed border-brand-border rounded-lg">
                      <span className="text-xs text-brand-muted">Drop here</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>
      <Footer />
    </div>
  );
}
