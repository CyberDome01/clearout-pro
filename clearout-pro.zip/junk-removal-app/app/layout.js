import './globals.css';

export const metadata = {
  title: 'ClearOut Pro — Edmonton Junk Removal',
  description: 'Professional junk removal & hauling services in Edmonton, AB. Fast, affordable, eco-friendly.',
  keywords: 'junk removal Edmonton, hauling, cleanout, furniture removal, appliance removal',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-brand-dark text-brand-text font-body antialiased">
        {children}
      </body>
    </html>
  );
}
