'use client';
import { useState } from 'react';
import Link from 'next/link';
import {
  Truck, CheckCircle, Phone, Star, ArrowRight, Zap, Shield, Leaf,
  ChevronDown, Menu, X, Clock, DollarSign, ThumbsUp
} from 'lucide-react';
import Footer from '@/components/Footer';

const services = [
  { name: 'Full Junk Removal', price: 'From $150', icon: '🗑️' },
  { name: 'Furniture Removal', price: 'From $75', icon: '🛋️' },
  { name: 'Appliance Removal', price: 'From $85', icon: '🔌' },
  { name: 'Garage Cleanout', price: 'From $399', icon: '🏠' },
  { name: 'Estate Cleanout', price: 'From $699', icon: '📦' },
  { name: 'Yard Waste', price: 'From $120', icon: '🌿' },
];

const reviews = [
  { name: 'Sarah M.', rating: 5, text: 'They came same day and cleared our entire basement. Super professional and quick!', area: 'Glenora' },
  { name: 'James T.', rating: 5, text: 'Best junk removal in Edmonton. Fair price, showed up on time. Will use again!', area: 'Windermere' },
  { name: 'Priya K.', rating: 5, text: 'Removed our old fridge and couch in under 30 minutes. Highly recommended.', area: 'Millwoods' },
];

const faqs = [
  { q: 'How quickly can you come?', a: 'We offer same-day and next-day service for most jobs in Edmonton. Book before noon for same-day availability.' },
  { q: 'How do you price jobs?', a: 'Pricing is based on truck space used. We give you a free on-site or photo estimate with no hidden fees.' },
  { q: 'What items do you take?', a: 'Almost everything: furniture, appliances, electronics, yard waste, construction debris, and more. We cannot take hazardous materials (paint, chemicals, tires).' },
  { q: 'Do you recycle or donate?', a: 'Yes! We divert up to 60% of items away from landfill through donation centres, recycling programs, and scrap metal.' },
];

export default function LandingPage() {
  const [openFaq, setOpenFaq] = useState(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [formData, setFormData] = useState({
    name: '', phone: '', email: '', service: '', message: '', source: '', address: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) setSubmitted(true);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-brand-dark min-h-screen">
      {/* ── TOP NAV ── */}
      <header className="bg-brand-card/80 backdrop-blur-md border-b border-brand-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-orange rounded-lg flex items-center justify-center">
              <Truck size={15} className="text-white" />
            </div>
            <span className="font-display text-2xl text-white tracking-wide">
              CLEAR<span className="text-brand-orange">OUT</span> PRO
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm text-brand-muted">
            <a href="#services" className="hover:text-white transition-colors">Services</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
            <a href="#reviews" className="hover:text-white transition-colors">Reviews</a>
            <a href="#about" className="hover:text-white transition-colors">About</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </nav>

          <div className="flex items-center gap-3">
            <a href="tel:+17801234567" className="hidden sm:flex items-center gap-2 text-sm text-brand-orange font-semibold hover:text-brand-orangeLight transition-colors">
              <Phone size={14} />
              (780) 123-4567
            </a>
            <a href="#quote" className="btn-primary text-sm py-2 px-4">
              Free Quote
            </a>
            <button onClick={() => setMobileMenu(!mobileMenu)} className="md:hidden text-brand-muted p-1">
              {mobileMenu ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {mobileMenu && (
          <div className="md:hidden bg-brand-card border-t border-brand-border px-4 py-3 space-y-2">
            {['services', 'pricing', 'reviews', 'about', 'faq'].map(s => (
              <a key={s} href={`#${s}`} onClick={() => setMobileMenu(false)}
                className="block py-2 text-brand-muted capitalize hover:text-white transition-colors">
                {s}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* ── HERO ── */}
      <section className="relative overflow-hidden pt-16 pb-20 px-4">
        {/* Background gradient */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-brand-orange/8 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-brand-orange/5 rounded-full blur-2xl" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="max-w-3xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-brand-orange/15 border border-brand-orange/30 rounded-full px-4 py-1.5 mb-6">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse-soft" />
              <span className="text-sm text-brand-orange font-medium">Available Today in Edmonton</span>
            </div>

            <h1 className="font-display text-6xl sm:text-7xl lg:text-8xl text-white leading-none mb-6">
              JUNK GONE.<br />
              <span className="text-brand-orange">SAME DAY.</span>
            </h1>

            <p className="text-xl text-brand-muted max-w-lg mb-8 leading-relaxed">
              Edmonton's trusted junk removal crew. We haul it all — furniture, appliances, garage cleanouts, and more. Upfront pricing. No surprises.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#quote" className="btn-primary text-base px-8 py-4 inline-flex items-center justify-center gap-2">
                Get a Free Quote
                <ArrowRight size={18} />
              </a>
              <a href="tel:+17801234567" className="flex items-center justify-center gap-2 border border-brand-border text-brand-text rounded-lg px-8 py-4 hover:border-brand-orange transition-all duration-200">
                <Phone size={18} className="text-brand-orange" />
                Call Us Now
              </a>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-6 mt-10 text-sm text-brand-muted">
              {[
                { icon: Zap, text: 'Same-Day Available' },
                { icon: Shield, text: 'Fully Insured' },
                { icon: Leaf, text: 'Eco-Friendly Disposal' },
                { icon: ThumbsUp, text: '200+ 5-Star Reviews' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-2">
                  <Icon size={14} className="text-brand-orange" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── STATS STRIP ── */}
      <section className="bg-brand-orange py-8 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: '1,200+', label: 'Jobs Completed' },
            { number: '4.9★', label: 'Average Rating' },
            { number: '2 hrs', label: 'Avg Response Time' },
            { number: '60%', label: 'Diverted from Landfill' },
          ].map(({ number, label }) => (
            <div key={label} className="text-center">
              <div className="font-display text-4xl text-white">{number}</div>
              <div className="text-white/80 text-sm mt-1">{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section id="services" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">What We Do</p>
            <h2 className="font-display text-5xl text-white">OUR SERVICES</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.map((svc) => (
              <div
                key={svc.name}
                className="bg-brand-card border border-brand-border rounded-xl p-6 card-hover cursor-pointer group"
              >
                <div className="text-4xl mb-4">{svc.icon}</div>
                <h3 className="font-semibold text-white text-lg mb-1 group-hover:text-brand-orange transition-colors">
                  {svc.name}
                </h3>
                <p className="text-brand-orange text-sm font-semibold">{svc.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-20 px-4 bg-brand-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12 text-center">
            <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">Simple Process</p>
            <h2 className="font-display text-5xl text-white">HOW IT WORKS</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {[
              { step: '01', icon: Phone, title: 'Book Online or Call', desc: 'Fill out our quick form or call us directly. We\'ll confirm your appointment in under 2 hours.' },
              { step: '02', icon: Truck, title: 'We Show Up', desc: 'Our crew arrives in the booked window. We assess the job, give you a final price, and get to work.' },
              { step: '03', icon: CheckCircle, title: 'Space Cleared, You\'re Done', desc: 'We haul everything away, sweep up, and you\'re left with a clean space. Simple as that.' },
            ].map(({ step, icon: Icon, title, desc }) => (
              <div key={step} className="relative text-center md:text-left">
                <div className="font-display text-8xl text-brand-border absolute top-0 left-0 md:left-0 leading-none -z-0 select-none">
                  {step}
                </div>
                <div className="relative z-10 pt-8">
                  <div className="w-12 h-12 bg-brand-orange/20 border border-brand-orange/30 rounded-xl flex items-center justify-center mb-4 mx-auto md:mx-0">
                    <Icon size={20} className="text-brand-orange" />
                  </div>
                  <h3 className="font-semibold text-white text-lg mb-2">{title}</h3>
                  <p className="text-brand-muted text-sm leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ── */}
      <section id="pricing" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">Transparent Pricing</p>
            <h2 className="font-display text-5xl text-white">WHAT DOES IT COST?</h2>
            <p className="text-brand-muted mt-3 max-w-lg">All prices include labour, disposal fees, and fuel. No hidden charges, ever.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { size: '1/4 Load', price: '$150', desc: 'A few items or bags' },
              { size: '1/2 Load', price: '$250', desc: 'A room\'s worth of items', highlight: false },
              { size: '3/4 Load', price: '$350', desc: 'Most popular size', highlight: true },
              { size: 'Full Load', price: '$450', desc: 'Fill the truck' },
            ].map(({ size, price, desc, highlight }) => (
              <div
                key={size}
                className={`rounded-xl p-6 border transition-all duration-200 ${
                  highlight
                    ? 'bg-brand-orange border-brand-orange text-white relative overflow-hidden'
                    : 'bg-brand-card border-brand-border card-hover'
                }`}
              >
                {highlight && (
                  <div className="absolute top-3 right-3 bg-white/20 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    POPULAR
                  </div>
                )}
                <div className={`font-display text-xl mb-2 ${highlight ? 'text-white/80' : 'text-brand-muted'}`}>
                  {size}
                </div>
                <div className={`font-display text-5xl mb-2 ${highlight ? 'text-white' : 'text-white'}`}>
                  {price}
                </div>
                <p className={`text-sm ${highlight ? 'text-white/80' : 'text-brand-muted'}`}>{desc}</p>
              </div>
            ))}
          </div>

          <p className="text-brand-muted text-sm mt-6 text-center">
            * Appliances: $85/item &nbsp;|&nbsp; Garage cleanouts from $399 &nbsp;|&nbsp; Estate cleanouts from $699
          </p>
        </div>
      </section>

      {/* ── REVIEWS ── */}
      <section id="reviews" className="py-20 px-4 bg-brand-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12 text-center">
            <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">Happy Customers</p>
            <h2 className="font-display text-5xl text-white">WHAT PEOPLE SAY</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reviews.map((r) => (
              <div key={r.name} className="bg-brand-card border border-brand-border rounded-xl p-6 card-hover">
                <div className="flex gap-0.5 mb-4">
                  {[...Array(r.rating)].map((_, i) => (
                    <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-brand-text text-sm leading-relaxed mb-4">"{r.text}"</p>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-brand-orange/20 rounded-full flex items-center justify-center text-xs font-bold text-brand-orange">
                    {r.name[0]}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">{r.name}</div>
                    <div className="text-xs text-brand-muted">{r.area}, Edmonton</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">Who We Are</p>
              <h2 className="font-display text-5xl text-white mb-6">OUR MISSION</h2>
              <div className="space-y-4 text-brand-muted leading-relaxed">
                <p>
                  At <span className="text-white font-semibold">ClearOut Pro</span>, our mission is simple: <span className="text-brand-orange">give every Edmonton home and business a fresh start.</span>
                </p>
                <p>
                  We believe that a clutter-free space leads to a clearer mind. Whether you're clearing out a loved one's estate, renovating a basement, or just tired of looking at that old couch — we're the crew you call.
                </p>
                <p>
                  We built this company on three principles: <strong className="text-white">honest pricing</strong>, <strong className="text-white">reliable service</strong>, and <strong className="text-white">doing right by our community</strong> — which means responsible disposal and donating items that still have life in them.
                </p>
                <p>
                  We're proudly Edmonton-based and treat every job, big or small, with the same hustle and care.
                </p>
              </div>
              <div className="flex flex-wrap gap-4 mt-8">
                {[
                  { icon: Clock, text: 'Same-Day Service' },
                  { icon: Shield, text: 'Fully Insured' },
                  { icon: DollarSign, text: 'No Hidden Fees' },
                ].map(({ icon: Icon, text }) => (
                  <div key={text} className="flex items-center gap-2 bg-brand-card border border-brand-border rounded-lg px-4 py-2">
                    <Icon size={14} className="text-brand-orange" />
                    <span className="text-sm text-brand-text">{text}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-brand-card border border-brand-border rounded-2xl p-8">
              <div className="font-display text-3xl text-white mb-4 tracking-wide">WHY EDMONTON CHOOSES US</div>
              <div className="space-y-4">
                {[
                  'We pick up the phone — always',
                  'On-site quotes at no charge',
                  'Two-man crew for safe, efficient removal',
                  'We take items you\'d expect others to refuse',
                  'Eco-friendly disposal — we donate & recycle first',
                  'Transparent truck-load pricing, not hourly guessing',
                  'Follow-up to make sure you\'re satisfied',
                ].map((point) => (
                  <div key={point} className="flex items-start gap-3">
                    <CheckCircle size={16} className="text-brand-orange flex-shrink-0 mt-0.5" />
                    <span className="text-brand-muted text-sm">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── QUOTE FORM ── */}
      <section id="quote" className="py-20 px-4 bg-brand-card/30">
        <div className="max-w-2xl mx-auto">
          <div className="mb-10 text-center">
            <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">It's Free</p>
            <h2 className="font-display text-5xl text-white">GET A QUOTE</h2>
            <p className="text-brand-muted mt-3">Fill in the form and we'll respond within 2 hours.</p>
          </div>

          {submitted ? (
            <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-10 text-center">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={28} className="text-green-400" />
              </div>
              <h3 className="font-display text-3xl text-white mb-2">QUOTE RECEIVED!</h3>
              <p className="text-brand-muted">We'll call or text you within 2 hours to confirm your quote. Thank you!</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-brand-card border border-brand-border rounded-2xl p-8 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-brand-text mb-1.5">Full Name *</label>
                  <input
                    type="text" required
                    className="input-dark"
                    placeholder="Your name"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-brand-text mb-1.5">Phone Number *</label>
                  <input
                    type="tel" required
                    className="input-dark"
                    placeholder="(780) 000-0000"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-brand-text mb-1.5">Email (optional)</label>
                <input
                  type="email"
                  className="input-dark"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-brand-text mb-1.5">Pickup Address *</label>
                <input
                  type="text" required
                  className="input-dark"
                  placeholder="Street address, Edmonton, AB"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-brand-text mb-1.5">Service Type *</label>
                <select
                  required
                  className="input-dark"
                  value={formData.service}
                  onChange={e => setFormData({ ...formData, service: e.target.value })}
                >
                  <option value="">Select a service...</option>
                  {services.map(s => (
                    <option key={s.name} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-brand-text mb-1.5">How did you find us?</label>
                <select
                  className="input-dark"
                  value={formData.source}
                  onChange={e => setFormData({ ...formData, source: e.target.value })}
                >
                  <option value="">Select...</option>
                  {['Facebook Ad', 'Facebook Group Post', 'Google Search', 'Google Ad', 'Kijiji', 'Nextdoor', 'Friend Referral', 'Other'].map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-brand-text mb-1.5">Tell us about the job *</label>
                <textarea
                  required rows={4}
                  className="input-dark resize-none"
                  placeholder="What items need to be removed? Roughly how much? Any special access (stairs, locked gate, etc.)?"
                  value={formData.message}
                  onChange={e => setFormData({ ...formData, message: e.target.value })}
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-4 text-base flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <span className="animate-spin border-2 border-white/30 border-t-white rounded-full w-5 h-5" />
                ) : (
                  <>
                    Send My Free Quote Request
                    <ArrowRight size={18} />
                  </>
                )}
              </button>

              <p className="text-xs text-brand-muted text-center">
                We respond within 2 hours. No spam, ever.
              </p>
            </form>
          )}
        </div>
      </section>

      {/* ── FAQ ── */}
      <section id="faq" className="py-20 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="mb-12 text-center">
            <p className="text-brand-orange text-sm font-semibold uppercase tracking-widest mb-2">Got Questions?</p>
            <h2 className="font-display text-5xl text-white">FAQs</h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-brand-card border border-brand-border rounded-xl overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-6 py-4 text-left"
                >
                  <span className="font-medium text-white">{faq.q}</span>
                  <ChevronDown
                    size={16}
                    className={`text-brand-muted flex-shrink-0 transition-transform ${openFaq === i ? 'rotate-180 text-brand-orange' : ''}`}
                  />
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-4 text-brand-muted text-sm leading-relaxed border-t border-brand-border pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA STRIP ── */}
      <section className="py-16 px-4 bg-brand-orange relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)' , backgroundSize: '20px 20px'}} />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="font-display text-5xl sm:text-6xl text-white mb-4">
            READY TO CLEAR IT OUT?
          </h2>
          <p className="text-white/80 mb-8 text-lg">
            Call us now or submit a quote — we'll take it from there.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+17801234567"
              className="bg-white text-brand-orange font-bold px-8 py-4 rounded-lg hover:bg-brand-dark hover:text-white transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Phone size={18} />
              (780) 123-4567
            </a>
            <a
              href="#quote"
              className="border-2 border-white text-white font-bold px-8 py-4 rounded-lg hover:bg-white hover:text-brand-orange transition-all duration-200 flex items-center justify-center gap-2"
            >
              Get a Free Quote
              <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
