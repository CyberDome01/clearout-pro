'use client';
import { useState } from 'react';
import { Edit2, Save, X, Plus, Trash2, CheckCircle } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { MOCK_PRICING, formatCurrency } from '@/lib/utils';

export default function PricingPage() {
  const [pricing, setPricing] = useState(MOCK_PRICING);
  const [editing, setEditing] = useState(null);
  const [editData, setEditData] = useState({});
  const [saved, setSaved] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newItem, setNewItem] = useState({ service_name: '', base_price: '', unit: 'flat', description: '' });

  function startEdit(item) {
    setEditing(item.id);
    setEditData({ ...item });
  }

  function saveEdit() {
    setPricing(prev => prev.map(p => p.id === editing ? { ...editData, base_price: Number(editData.base_price) } : p));
    setEditing(null);
    flashSaved();
  }

  function deleteItem(id) {
    setPricing(prev => prev.filter(p => p.id !== id));
  }

  function addItem(e) {
    e.preventDefault();
    if (!newItem.service_name || !newItem.base_price) return;
    setPricing(prev => [...prev, { ...newItem, id: Date.now().toString(), base_price: Number(newItem.base_price) }]);
    setNewItem({ service_name: '', base_price: '', unit: 'flat', description: '' });
    setShowAdd(false);
    flashSaved();
  }

  function flashSaved() {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const unitLabels = { flat: 'Flat Rate', per_item: 'Per Item', starting: 'Starting At', hourly: '/hour' };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-4xl text-white tracking-wide">PRICING CONFIG</h1>
            <p className="text-brand-muted text-sm mt-1">Set your service rates. These feed into quote calculations.</p>
          </div>
          <div className="flex items-center gap-3">
            {saved && (
              <div className="flex items-center gap-2 text-green-400 text-sm animate-fade-up">
                <CheckCircle size={14} />
                Saved!
              </div>
            )}
            <button
              onClick={() => setShowAdd(!showAdd)}
              className="btn-primary flex items-center gap-2 text-sm"
            >
              <Plus size={16} />
              Add Service
            </button>
          </div>
        </div>

        {/* Add new item form */}
        {showAdd && (
          <form onSubmit={addItem} className="bg-brand-orange/10 border border-brand-orange/30 rounded-xl p-5 mb-6">
            <h3 className="font-display text-lg text-white tracking-wide mb-4">ADD NEW SERVICE</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <input
                required placeholder="Service name"
                className="input-dark text-sm"
                value={newItem.service_name}
                onChange={e => setNewItem(p => ({ ...p, service_name: e.target.value }))}
              />
              <input
                required type="number" placeholder="Price ($)" min="0" step="0.01"
                className="input-dark text-sm"
                value={newItem.base_price}
                onChange={e => setNewItem(p => ({ ...p, base_price: e.target.value }))}
              />
              <select
                className="input-dark text-sm"
                value={newItem.unit}
                onChange={e => setNewItem(p => ({ ...p, unit: e.target.value }))}
              >
                {Object.entries(unitLabels).map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </select>
              <input
                placeholder="Short description"
                className="input-dark text-sm"
                value={newItem.description}
                onChange={e => setNewItem(p => ({ ...p, description: e.target.value }))}
              />
            </div>
            <div className="flex gap-3 mt-4">
              <button type="submit" className="btn-primary text-sm py-2 px-4">Add Service</button>
              <button type="button" onClick={() => setShowAdd(false)} className="text-brand-muted text-sm hover:text-white transition-colors">Cancel</button>
            </div>
          </form>
        )}

        {/* Pricing Table */}
        <div className="bg-brand-card border border-brand-border rounded-xl overflow-hidden">
          <div className="grid grid-cols-12 px-5 py-3 border-b border-brand-border text-xs font-semibold text-brand-muted uppercase tracking-wider">
            <div className="col-span-3">Service</div>
            <div className="col-span-2">Price</div>
            <div className="col-span-2">Unit</div>
            <div className="col-span-4 hidden md:block">Description</div>
            <div className="col-span-1 text-right">Edit</div>
          </div>

          <div className="divide-y divide-brand-border">
            {pricing.map((item) => (
              <div key={item.id} className="grid grid-cols-12 px-5 py-4 items-center gap-2 hover:bg-white/3 transition-colors">
                {editing === item.id ? (
                  <>
                    <div className="col-span-3">
                      <input
                        className="input-dark text-sm"
                        value={editData.service_name}
                        onChange={e => setEditData(p => ({ ...p, service_name: e.target.value }))}
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="number" min="0" step="0.01"
                        className="input-dark text-sm"
                        value={editData.base_price}
                        onChange={e => setEditData(p => ({ ...p, base_price: e.target.value }))}
                      />
                    </div>
                    <div className="col-span-2">
                      <select
                        className="input-dark text-sm"
                        value={editData.unit}
                        onChange={e => setEditData(p => ({ ...p, unit: e.target.value }))}
                      >
                        {Object.entries(unitLabels).map(([val, label]) => (
                          <option key={val} value={val}>{label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-span-4 hidden md:block">
                      <input
                        className="input-dark text-sm"
                        value={editData.description}
                        onChange={e => setEditData(p => ({ ...p, description: e.target.value }))}
                      />
                    </div>
                    <div className="col-span-1 flex justify-end gap-1">
                      <button onClick={saveEdit} className="text-green-400 hover:text-green-300 p-1.5 hover:bg-green-400/10 rounded transition-all">
                        <Save size={14} />
                      </button>
                      <button onClick={() => setEditing(null)} className="text-brand-muted hover:text-white p-1.5 hover:bg-white/5 rounded transition-all">
                        <X size={14} />
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="col-span-3 font-medium text-white text-sm">{item.service_name}</div>
                    <div className="col-span-2 font-bold text-brand-orange">{formatCurrency(item.base_price)}</div>
                    <div className="col-span-2">
                      <span className="text-xs bg-brand-border text-brand-muted rounded-full px-2 py-0.5">
                        {unitLabels[item.unit] || item.unit}
                      </span>
                    </div>
                    <div className="col-span-4 hidden md:block text-brand-muted text-sm truncate">{item.description}</div>
                    <div className="col-span-1 flex justify-end gap-1">
                      <button onClick={() => startEdit(item)} className="text-brand-muted hover:text-brand-orange p-1.5 hover:bg-brand-orange/10 rounded transition-all">
                        <Edit2 size={14} />
                      </button>
                      <button onClick={() => deleteItem(item.id)} className="text-brand-muted hover:text-red-400 p-1.5 hover:bg-red-400/10 rounded transition-all">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Info box */}
        <div className="mt-6 bg-brand-card border border-brand-border rounded-xl p-6">
          <h3 className="font-display text-lg text-white tracking-wide mb-3">PRICING NOTES</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-brand-muted">
            <div>
              <p className="font-medium text-white mb-1">What's included in every job:</p>
              <ul className="space-y-1">
                <li>✓ Labour (2-man crew)</li>
                <li>✓ Loading & hauling</li>
                <li>✓ Eco-friendly disposal</li>
                <li>✓ Clean-up after removal</li>
              </ul>
            </div>
            <div>
              <p className="font-medium text-white mb-1">Not included (add-on pricing):</p>
              <ul className="space-y-1">
                <li>× Hazardous materials</li>
                <li>× Long carry (extra floor/stair fee)</li>
                <li>× Same-day rush (15% surcharge)</li>
                <li>× Hoarding cleanouts (hourly rate)</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
