import { NextResponse } from 'next/server';

export async function POST(request) {
  try {
    const body = await request.json();

    // Validate required fields
    const { name, phone, address, service, message } = body;
    if (!name || !phone || !address || !service || !message) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // ─────────────────────────────────────────────
    // 1. Save to Supabase
    // ─────────────────────────────────────────────
    // Uncomment and configure once you've set up Supabase:
    //
    // import { supabase } from '@/lib/supabase';
    //
    // const { data: customer, error: customerError } = await supabase
    //   .from('customers')
    //   .insert({ name, phone, email: body.email, address })
    //   .select()
    //   .single();
    //
    // if (customerError) throw customerError;
    //
    // const { error: jobError } = await supabase
    //   .from('jobs')
    //   .insert({
    //     customer_id: customer.id,
    //     service_type: service,
    //     notes: message,
    //     address,
    //     status: 'new',
    //     lead_source: body.source || 'Website',
    //   });
    //
    // if (jobError) throw jobError;

    // ─────────────────────────────────────────────
    // 2. Send email notification (Resend or similar)
    // ─────────────────────────────────────────────
    // const { Resend } = await import('resend');
    // const resend = new Resend(process.env.RESEND_API_KEY);
    // await resend.emails.send({
    //   from: 'noreply@clearoutpro.ca',
    //   to: 'your@email.com',
    //   subject: `New Quote Request — ${name}`,
    //   text: `
    //     New quote request from ${name}
    //     Phone: ${phone}
    //     Service: ${service}
    //     Address: ${address}
    //     Message: ${message}
    //     Lead source: ${body.source || 'Website'}
    //   `,
    // });

    // ─────────────────────────────────────────────
    // 3. Send SMS via Twilio (optional)
    // ─────────────────────────────────────────────
    // const twilio = require('twilio')(process.env.TWILIO_SID, process.env.TWILIO_AUTH);
    // await twilio.messages.create({
    //   to: process.env.OWNER_PHONE,
    //   from: process.env.TWILIO_PHONE,
    //   body: `🚨 New lead: ${name} | ${phone} | ${service}`,
    // });

    console.log('New quote request:', { name, phone, service, address });

    return NextResponse.json({ success: true, message: 'Quote request received.' });
  } catch (error) {
    console.error('Quote API error:', error);
    return NextResponse.json({ error: 'Server error. Please try again.' }, { status: 500 });
  }
}
