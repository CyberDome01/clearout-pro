'use client';
import { useState } from 'react';
import { CheckCircle, User, Phone, Mail, MapPin, Briefcase, MessageSquare, ArrowRight } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { MOCK_JOBS, SERVICE_TYPES, LEAD_SOURCES, formatCurrency, formatDate, STATUS_COLORS, STATUS_LABELS } from '@/lib/utils';

export default function QuotesPage() {
  const [form, setForm] = useState({
    customer_name: '', customer_phone: '', customer_email: '',
    address: '', service_type: '', notes: '',
    preferred_date: '', preferred_time: '',
    lead_source: '', estimated_price: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [recentLeads] = useState(MOCK_JOBS.filter(j => j.status === 'new' || j.status === 'quoted'));

  const set = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  function handleSubmit(e) {
    e.preventDefault();
    // In production: POST to Supabase or API route
    console.log('New quote:', form);
    setSubmitted(true);
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">

        <div className="mb-8">
          <h1 className="font-display text-4xl text-white tracking-wide">NEW QUOTE</h1>
          <p className="text-brand-muted text-sm mt-1">Add a new lead or customer inquiry to the job pipeline.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Form */}
          <div className="lg:col-span-2">
            {submitted ? (
              <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle size={28} className="text-green-400" />
                </div>
                <h3 className="font-display text-3xl text-white mb-2">LEAD ADDED!</h3>
                <p className="text-brand-muted mb-6">The new quote has been added to your job board under "New Leads".</p>
                <button
                  onClick={() => { setSubmitted(false); setForm({ customer_name: '', customer_phone: '', customer_email: '', address: '', service_type: '', notes: '', preferred_date: '', preferred_time: '', lead_source: '', estimated_price: '' }); }}
                  className="btn-primary"
                >
                  Add Another
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-brand-card border border-brand-border rounded-2xl p-8 space-y-6">

                {/* Customer Info */}
                <div>
                  <h3 className="font-display text-xl text-white tracking-wide mb-4 flex items-center gap-2">
                    <User size={16} className="text-brand-orange" />
                    CUSTOMER INFO
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-brand-text mb-1.5">Full Name *</label>
                      <input required className="input-dark" placeholder="Customer name" value={form.customer_name} onChange={e => set('customer_name', e.target.value)} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-text mb-1.5">Phone *</label>
                      <input required type="tel" className="input-dark" placeholder="(780) 000-0000" value={form.customer_phone} onChange={e => set('customer_phone', e.target.value)} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-text mb-1.5">Email</label>
                      <input type="email" className="input-dark" placeholder="email@example.com" value={form.customer_email} onChange={e => set('customer_email', e.target.value)} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-text mb-1.5">How Did They Find Us?</label>
                      <select className="input-dark" value={form.lead_source} onChange={e => set('lead_source', e.target.value)}>
                        <option value="">Select source...</option>
                        {LEAD_SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="border-t border-brand-border" />

                {/* Job Details */}
                <div>
                  <h3 className="font-display text-xl text-white tracking-wide mb-4 flex items-center gap-2">
                    <Briefcase size={16} className="text-brand-orange" />
                    JOB DETAILS
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-brand-text mb-1.5">Pickup Address *</label>
                      <input required className="input-dark" placeholder="Street address, Edmonton" value={form.address} onChange={e => set('address', e.target.value)} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-brand-text mb-1.5">Service Type *</label>
                        <select required className="input-dark" value={form.service_type} onChange={e => set('service_type', e.target.value)}>
                          <option value="">Select service...</option>
                          {SERVICE_TYPES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-brand-text mb-1.5">Estimated Price ($)</label>
                        <input type="number" className="input-dark" placeholder="e.g. 250" value={form.estimated_price} onChange={e => set('estimated_price', e.target.value)} />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-brand-text mb-1.5">Preferred Date</label>
                        <input type="date" className="input-dark" value={form.preferred_date} onChange={e => set('preferred_date', e.target.value)} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-brand-text mb-1.5">Preferred Time</label>
                        <select className="input-dark" value={form.preferred_time} onChange={e => set('preferred_time', e.target.value)}>
                          <option value="">Select window...</option>
                          {['7AM–10AM', '10AM–1PM', '1PM–4PM', '4PM–7PM', 'Flexible'].map(t => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-text mb-1.5">Notes</label>
                      <textarea rows={4} className="input-dark resize-none" placeholder="What needs to be removed? Stairs? Special access? Anything else?" value={form.notes} onChange={e => set('notes', e.target.value)} />
                    </div>
                  </div>
                </div>

                <button type="submit" className="btn-primary w-full py-4 flex items-center justify-center gap-2 text-base">
                  Add to Job Board
                  <ArrowRight size={18} />
                </button>
              </form>
            )}
          </div>

          {/* Sidebar — Recent Leads */}
          <div>
            <div className="bg-brand-card border border-brand-border rounded-xl">
              <div className="px-5 py-4 border-b border-brand-border">
                <h2 className="font-display text-lg text-white tracking-wide">PENDING LEADS</h2>
              </div>
              <div className="divide-y divide-brand-border">
                {recentLeads.map((job) => (
                  <div key={job.id} className="px-4 py-4">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="font-medium text-white text-sm">{job.customer_name}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${STATUS_COLORS[job.status]}`}>
                        {STATUS_LABELS[job.status]}
                      </span>
                    </div>
                    <div className="text-xs text-brand-muted mb-1">{job.service_type}</div>
                    <div className="flex items-center gap-1 text-xs text-brand-muted">
                      <Phone size={9} />
                      {job.customer_phone}
                    </div>
                    <div className="text-brand-orange font-semibold text-sm mt-2">{formatCurrency(job.price)}</div>
                  </div>
                ))}
                {recentLeads.length === 0 && (
                  <div className="px-4 py-8 text-center text-brand-muted text-sm">No pending leads.</div>
                )}
              </div>
            </div>

            {/* Tips */}
            <div className="mt-4 bg-brand-orange/10 border border-brand-orange/20 rounded-xl p-5">
              <h3 className="font-display text-base text-brand-orange tracking-wide mb-3">PRO TIPS</h3>
              <ul className="space-y-2 text-sm text-brand-muted">
                <li className="flex items-start gap-2">
                  <span className="text-brand-orange mt-0.5">→</span>
                  Always call within 30 min of a new lead coming in — response time = conversion rate.
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-brand-orange mt-0.5">→</span>
                  Ask for photos before quoting over the phone — reduces surprise on arrival.
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-brand-orange mt-0.5">→</span>
                  Always confirm the day before with a text message.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
