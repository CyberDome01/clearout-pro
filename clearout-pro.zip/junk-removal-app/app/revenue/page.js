'use client';
import { useState } from 'react';
import { TrendingUp, DollarSign, Fuel, Package, Trash2, Plus, X } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { MOCK_JOBS, formatCurrency, formatDate } from '@/lib/utils';

const MOCK_EXPENSES = [
  { id: '1', type: 'Fuel', amount: 85, note: 'June week 1', date: '2024-06-07' },
  { id: '2', type: 'Disposal Fee', amount: 120, note: 'Eco station drop', date: '2024-06-08' },
  { id: '3', type: 'Labor', amount: 200, note: 'Helper – Mike', date: '2024-06-12' },
  { id: '4', type: 'Fuel', amount: 90, note: 'June week 2', date: '2024-06-14' },
];

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const monthlyRevenue = [0, 0, 320, 890, 1450, 2245, 0, 0, 0, 0, 0, 0];
const maxRevenue = Math.max(...monthlyRevenue);

export default function RevenuePage() {
  const [expenses, setExpenses] = useState(MOCK_EXPENSES);
  const [expForm, setExpForm] = useState({ type: 'Fuel', amount: '', note: '', date: '' });
  const [showForm, setShowForm] = useState(false);

  const paidJobs = MOCK_JOBS.filter(j => j.status === 'paid' || j.status === 'done');
  const totalRevenue = paidJobs.reduce((sum, j) => sum + j.price, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(0) : 0;

  function addExpense(e) {
    e.preventDefault();
    if (!expForm.amount) return;
    setExpenses(prev => [
      { id: Date.now().toString(), ...expForm, amount: Number(expForm.amount) },
      ...prev,
    ]);
    setExpForm({ type: 'Fuel', amount: '', note: '', date: '' });
    setShowForm(false);
  }

  function removeExpense(id) {
    setExpenses(prev => prev.filter(e => e.id !== id));
  }

  const expenseIcons = { Fuel: Fuel, 'Disposal Fee': Trash2, Labor: Package };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">

        <div className="mb-8">
          <h1 className="font-display text-4xl text-white tracking-wide">REVENUE</h1>
          <p className="text-brand-muted text-sm mt-1">Track income, expenses, and profit.</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Revenue', value: formatCurrency(totalRevenue), icon: DollarSign, color: 'text-green-400', bg: 'bg-green-400/10' },
            { label: 'Total Expenses', value: formatCurrency(totalExpenses), icon: TrendingUp, color: 'text-red-400', bg: 'bg-red-400/10' },
            { label: 'Net Profit', value: formatCurrency(netProfit), icon: TrendingUp, color: 'text-brand-orange', bg: 'bg-brand-orange/10' },
            { label: 'Profit Margin', value: `${profitMargin}%`, icon: TrendingUp, color: 'text-purple-400', bg: 'bg-purple-400/10' },
          ].map(({ label, value, icon: Icon, color, bg }) => (
            <div key={label} className="bg-brand-card border border-brand-border rounded-xl p-5 card-hover">
              <div className={`w-9 h-9 ${bg} rounded-xl flex items-center justify-center mb-3`}>
                <Icon size={16} className={color} />
              </div>
              <div className="font-display text-3xl text-white">{value}</div>
              <div className="text-brand-muted text-xs mt-1">{label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Monthly Chart */}
          <div className="bg-brand-card border border-brand-border rounded-xl p-6">
            <h2 className="font-display text-xl text-white tracking-wide mb-6">MONTHLY REVENUE</h2>
            <div className="flex items-end gap-2 h-40">
              {months.map((month, i) => {
                const val = monthlyRevenue[i];
                const pct = maxRevenue > 0 ? (val / maxRevenue) * 100 : 0;
                const isCurrent = i === 5;
                return (
                  <div key={month} className="flex-1 flex flex-col items-center gap-1">
                    <div className="relative w-full group">
                      {val > 0 && (
                        <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-brand-orange text-white text-xs px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                          {formatCurrency(val)}
                        </div>
                      )}
                      <div
                        className={`w-full rounded-t-sm transition-all duration-500 ${
                          isCurrent ? 'bg-brand-orange' : val > 0 ? 'bg-brand-orange/40' : 'bg-brand-border'
                        }`}
                        style={{ height: `${Math.max(pct, 4)}%`, minHeight: '4px' }}
                      />
                    </div>
                    <span className="text-xs text-brand-muted">{month}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Completed Jobs */}
          <div className="bg-brand-card border border-brand-border rounded-xl">
            <div className="px-5 py-4 border-b border-brand-border">
              <h2 className="font-display text-xl text-white tracking-wide">COMPLETED JOBS</h2>
            </div>
            <div className="divide-y divide-brand-border">
              {paidJobs.map((job) => (
                <div key={job.id} className="px-5 py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="font-medium text-white text-sm">{job.customer_name}</div>
                    <div className="text-xs text-brand-muted">{job.service_type} · {formatDate(job.preferred_date)}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${job.status === 'paid' ? 'badge-paid' : 'badge-done'}`}>
                      {job.status === 'paid' ? 'Paid' : 'Done'}
                    </span>
                    <span className="font-bold text-white text-sm">{formatCurrency(job.price)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Expenses */}
        <div className="mt-6 bg-brand-card border border-brand-border rounded-xl">
          <div className="px-5 py-4 border-b border-brand-border flex items-center justify-between">
            <h2 className="font-display text-xl text-white tracking-wide">EXPENSES</h2>
            <button
              onClick={() => setShowForm(!showForm)}
              className="btn-primary text-sm py-2 px-3 flex items-center gap-2"
            >
              <Plus size={14} />
              Add Expense
            </button>
          </div>

          {showForm && (
            <form onSubmit={addExpense} className="px-5 py-4 border-b border-brand-border bg-brand-dark/50">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <select
                  className="input-dark text-sm"
                  value={expForm.type}
                  onChange={e => setExpForm(p => ({ ...p, type: e.target.value }))}
                >
                  {['Fuel', 'Disposal Fee', 'Labor', 'Equipment', 'Marketing', 'Other'].map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
                <input
                  type="number" required placeholder="Amount ($)" step="0.01"
                  className="input-dark text-sm"
                  value={expForm.amount}
                  onChange={e => setExpForm(p => ({ ...p, amount: e.target.value }))}
                />
                <input
                  type="text" placeholder="Note"
                  className="input-dark text-sm"
                  value={expForm.note}
                  onChange={e => setExpForm(p => ({ ...p, note: e.target.value }))}
                />
                <div className="flex gap-2">
                  <input
                    type="date"
                    className="input-dark text-sm flex-1"
                    value={expForm.date}
                    onChange={e => setExpForm(p => ({ ...p, date: e.target.value }))}
                  />
                  <button type="submit" className="btn-primary px-3 py-2 text-sm">Add</button>
                </div>
              </div>
            </form>
          )}

          <div className="divide-y divide-brand-border">
            {expenses.map((exp) => {
              const Icon = expenseIcons[exp.type] || DollarSign;
              return (
                <div key={exp.id} className="px-5 py-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-red-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon size={14} className="text-red-400" />
                    </div>
                    <div>
                      <div className="font-medium text-white text-sm">{exp.type}</div>
                      <div className="text-xs text-brand-muted">{exp.note} {exp.date && `· ${formatDate(exp.date)}`}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-red-400 text-sm">-{formatCurrency(exp.amount)}</span>
                    <button
                      onClick={() => removeExpense(exp.id)}
                      className="text-brand-muted hover:text-red-400 transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="px-5 py-4 border-t border-brand-border flex items-center justify-between">
            <span className="font-display text-base text-white tracking-wide">TOTAL EXPENSES</span>
            <span className="font-bold text-red-400">{formatCurrency(totalExpenses)}</span>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
