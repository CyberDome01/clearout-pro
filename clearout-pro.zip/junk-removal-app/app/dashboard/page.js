'use client';
import { useState } from 'react';
import Link from 'next/link';
import {
  TrendingUp, Users, Briefcase, DollarSign, ArrowRight,
  Clock, CheckCircle, AlertCircle, Phone, MapPin, Plus
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { MOCK_JOBS, formatCurrency, formatDate, STATUS_COLORS, STATUS_LABELS } from '@/lib/utils';

const stats = [
  {
    label: 'This Month Revenue',
    value: formatCurrency(2245),
    change: '+18%',
    positive: true,
    icon: DollarSign,
    color: 'text-green-400',
    bg: 'bg-green-400/10',
  },
  {
    label: 'Active Jobs',
    value: '6',
    change: '+2 this week',
    positive: true,
    icon: Briefcase,
    color: 'text-brand-orange',
    bg: 'bg-brand-orange/10',
  },
  {
    label: 'Total Customers',
    value: '38',
    change: '+5 this month',
    positive: true,
    icon: Users,
    color: 'text-blue-400',
    bg: 'bg-blue-400/10',
  },
  {
    label: 'Avg Job Value',
    value: formatCurrency(340),
    change: '+$40 vs last month',
    positive: true,
    icon: TrendingUp,
    color: 'text-purple-400',
    bg: 'bg-purple-400/10',
  },
];

const quickActions = [
  { label: 'Add New Lead', href: '/quotes', icon: Plus, color: 'bg-brand-orange' },
  { label: 'View All Jobs', href: '/jobs', icon: Briefcase, color: 'bg-blue-600' },
  { label: 'Revenue Report', href: '/revenue', icon: TrendingUp, color: 'bg-green-600' },
  { label: 'Edit Pricing', href: '/pricing', icon: DollarSign, color: 'bg-purple-600' },
];

export default function Dashboard() {
  const recentJobs = MOCK_JOBS.slice(0, 5);
  const todayJobs = MOCK_JOBS.filter(j => j.status === 'booked');

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-4xl text-white tracking-wide">DASHBOARD</h1>
            <p className="text-brand-muted text-sm mt-1">Welcome back — here's what's happening today.</p>
          </div>
          <Link href="/quotes" className="btn-primary flex items-center gap-2 text-sm">
            <Plus size={16} />
            New Quote
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
          {stats.map(({ label, value, change, positive, icon: Icon, color, bg }) => (
            <div key={label} className="bg-brand-card border border-brand-border rounded-xl p-5 card-hover">
              <div className="flex items-start justify-between mb-4">
                <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center`}>
                  <Icon size={18} className={color} />
                </div>
                <span className={`text-xs font-medium ${positive ? 'text-green-400' : 'text-red-400'}`}>
                  {change}
                </span>
              </div>
              <div className="font-display text-3xl text-white">{value}</div>
              <div className="text-brand-muted text-xs mt-1">{label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Recent Jobs */}
          <div className="lg:col-span-2 bg-brand-card border border-brand-border rounded-xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-brand-border">
              <h2 className="font-display text-xl text-white tracking-wide">RECENT JOBS</h2>
              <Link href="/jobs" className="text-brand-orange text-sm hover:text-brand-orangeLight flex items-center gap-1">
                View all <ArrowRight size={13} />
              </Link>
            </div>
            <div className="divide-y divide-brand-border">
              {recentJobs.map((job) => (
                <div key={job.id} className="px-6 py-4 hover:bg-white/3 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-white text-sm">{job.customer_name}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[job.status]}`}>
                          {STATUS_LABELS[job.status]}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-brand-muted mb-1">
                        <MapPin size={10} />
                        {job.address}
                      </div>
                      <div className="text-xs text-brand-muted">{job.service_type}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="font-semibold text-white text-sm">{formatCurrency(job.price)}</div>
                      <div className="text-xs text-brand-muted mt-0.5">{formatDate(job.preferred_date)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Today's Jobs */}
            <div className="bg-brand-card border border-brand-border rounded-xl">
              <div className="px-5 py-4 border-b border-brand-border">
                <h2 className="font-display text-lg text-white tracking-wide flex items-center gap-2">
                  <Clock size={15} className="text-brand-orange" />
                  TODAY'S JOBS
                </h2>
              </div>
              <div className="p-4 space-y-3">
                {todayJobs.length === 0 ? (
                  <p className="text-brand-muted text-sm text-center py-4">No jobs scheduled today.</p>
                ) : (
                  todayJobs.map((job) => (
                    <div key={job.id} className="bg-brand-dark rounded-lg p-3 border border-brand-border">
                      <div className="font-medium text-white text-sm">{job.customer_name}</div>
                      <div className="text-xs text-brand-muted mt-1 flex items-center gap-1">
                        <Phone size={10} />
                        {job.customer_phone}
                      </div>
                      <div className="text-xs text-brand-muted mt-0.5">{job.service_type}</div>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="font-semibold text-brand-orange text-sm">{formatCurrency(job.price)}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-brand-card border border-brand-border rounded-xl">
              <div className="px-5 py-4 border-b border-brand-border">
                <h2 className="font-display text-lg text-white tracking-wide">QUICK ACTIONS</h2>
              </div>
              <div className="p-4 grid grid-cols-2 gap-2">
                {quickActions.map(({ label, href, icon: Icon, color }) => (
                  <Link
                    key={href}
                    href={href}
                    className="flex flex-col items-center gap-2 p-4 bg-brand-dark border border-brand-border rounded-xl hover:border-brand-orange transition-all duration-200 text-center group"
                  >
                    <div className={`w-9 h-9 ${color} rounded-lg flex items-center justify-center`}>
                      <Icon size={16} className="text-white" />
                    </div>
                    <span className="text-xs text-brand-muted group-hover:text-white transition-colors leading-tight">{label}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Lead Sources */}
            <div className="bg-brand-card border border-brand-border rounded-xl">
              <div className="px-5 py-4 border-b border-brand-border">
                <h2 className="font-display text-lg text-white tracking-wide">LEAD SOURCES</h2>
              </div>
              <div className="p-4 space-y-3">
                {[
                  { source: 'Facebook', count: 12, pct: 40 },
                  { source: 'Google', count: 9, pct: 30 },
                  { source: 'Kijiji', count: 5, pct: 17 },
                  { source: 'Referrals', count: 4, pct: 13 },
                ].map(({ source, count, pct }) => (
                  <div key={source}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-brand-muted">{source}</span>
                      <span className="text-white font-medium">{count} leads</span>
                    </div>
                    <div className="w-full bg-brand-border rounded-full h-1.5">
                      <div
                        className="bg-brand-orange h-1.5 rounded-full transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
