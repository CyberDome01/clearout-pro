-- ============================================================
-- ClearOut Pro — Supabase Database Schema
-- Run this in your Supabase SQL Editor:
-- https://app.supabase.com → SQL Editor → New Query
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ─── Customers ───────────────────────────────────────────────
create table customers (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  phone       text not null,
  email       text,
  address     text,
  lead_source text,
  notes       text,
  created_at  timestamptz default now()
);

-- ─── Jobs ────────────────────────────────────────────────────
create type job_status as enum ('new', 'quoted', 'booked', 'done', 'paid');

create table jobs (
  id             uuid primary key default uuid_generate_v4(),
  customer_id    uuid references customers(id) on delete set null,
  service_type   text not null,
  status         job_status default 'new',
  price          numeric(10,2) default 0,
  notes          text,
  address        text,
  preferred_date date,
  preferred_time text,
  lead_source    text,
  created_at     timestamptz default now(),
  updated_at     timestamptz default now()
);

-- Auto-update updated_at
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger jobs_updated_at
  before update on jobs
  for each row execute procedure update_updated_at();

-- ─── Job Images (before/after photos) ────────────────────────
create table job_images (
  id          uuid primary key default uuid_generate_v4(),
  job_id      uuid references jobs(id) on delete cascade,
  url         text not null,
  type        text check (type in ('before', 'after', 'other')) default 'other',
  uploaded_at timestamptz default now()
);

-- ─── Expenses ────────────────────────────────────────────────
create table expenses (
  id         uuid primary key default uuid_generate_v4(),
  job_id     uuid references jobs(id) on delete set null,
  type       text not null, -- fuel, labor, disposal, equipment, etc.
  amount     numeric(10,2) not null,
  note       text,
  date       date default current_date,
  created_at timestamptz default now()
);

-- ─── Pricing Config ──────────────────────────────────────────
create table pricing (
  id           uuid primary key default uuid_generate_v4(),
  service_name text not null,
  base_price   numeric(10,2) not null,
  unit         text default 'flat', -- flat, per_item, starting, hourly
  description  text,
  active       boolean default true,
  created_at   timestamptz default now()
);

-- Seed pricing data
insert into pricing (service_name, base_price, unit, description) values
  ('Single Item',     75,  'per_item', 'Chair, box spring, TV, etc.'),
  ('1/4 Truck Load', 150,  'flat',     'A few bags or small items'),
  ('1/2 Truck Load', 250,  'flat',     'Couple of furniture pieces'),
  ('3/4 Truck Load', 350,  'flat',     'Most of a room worth of junk'),
  ('Full Truck Load', 450, 'flat',     'Fill the whole truck'),
  ('Garage Cleanout', 399, 'starting', 'Full garage from $399'),
  ('Estate Cleanout', 699, 'starting', 'Full property from $699'),
  ('Appliance Removal', 85,'per_item', 'Fridge, washer, dryer, stove');

-- ─── Row Level Security (RLS) ─────────────────────────────────
-- Enable RLS on all tables (auth required to read/write)
alter table customers   enable row level security;
alter table jobs        enable row level security;
alter table job_images  enable row level security;
alter table expenses    enable row level security;
alter table pricing     enable row level security;

-- Allow authenticated users full access (your admin app)
create policy "Auth users can do everything" on customers
  for all using (auth.role() = 'authenticated');

create policy "Auth users can do everything" on jobs
  for all using (auth.role() = 'authenticated');

create policy "Auth users can do everything" on job_images
  for all using (auth.role() = 'authenticated');

create policy "Auth users can do everything" on expenses
  for all using (auth.role() = 'authenticated');

-- Allow public to read pricing (for website quote form)
create policy "Public can read pricing" on pricing
  for select using (true);

create policy "Auth users can manage pricing" on pricing
  for all using (auth.role() = 'authenticated');

-- ─── Storage bucket for job photos ───────────────────────────
-- Run this separately in Supabase Dashboard → Storage → New Bucket
-- Bucket name: job-photos
-- Public: false (only authenticated users)
