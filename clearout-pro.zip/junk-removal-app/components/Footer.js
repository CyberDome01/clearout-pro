import Link from 'next/link';
import { Truck, Phone, Mail, MapPin, Facebook, Instagram, Star } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-brand-card border-t border-brand-border mt-auto">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">

          {/* Brand Column */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-brand-orange rounded-lg flex items-center justify-center">
                <Truck size={18} className="text-white" />
              </div>
              <span className="font-display text-3xl text-white tracking-wide">
                CLEAR<span className="text-brand-orange">OUT</span> PRO
              </span>
            </div>

            {/* Mission Statement */}
            <div className="mb-5">
              <p className="text-brand-muted text-sm leading-relaxed mb-3">
                <span className="text-brand-orange font-semibold">Our Mission:</span> To give every Edmonton home and business a fresh start — removing the clutter, hauling away the stress, and leaving nothing behind but clean space and peace of mind.
              </p>
              <p className="text-brand-muted text-sm leading-relaxed">
                We believe in honest pricing, same-day service, and treating every property with respect. From single-item pickups to full estate cleanouts — we show up, we haul it, we're done.
              </p>
            </div>

            {/* Social */}
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 bg-brand-border rounded-lg flex items-center justify-center text-brand-muted hover:text-white hover:bg-brand-orange transition-all duration-200">
                <Facebook size={15} />
              </a>
              <a href="#" className="w-9 h-9 bg-brand-border rounded-lg flex items-center justify-center text-brand-muted hover:text-white hover:bg-brand-orange transition-all duration-200">
                <Instagram size={15} />
              </a>
              <a href="#" className="w-9 h-9 bg-brand-border rounded-lg flex items-center justify-center text-brand-muted hover:text-white hover:bg-orange-400 transition-all duration-200">
                <Star size={15} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-lg text-white tracking-wider mb-4">QUICK LINKS</h4>
            <ul className="space-y-2">
              {[
                { label: 'Get a Free Quote', href: '/#quote' },
                { label: 'Our Services', href: '/#services' },
                { label: 'Pricing', href: '/#pricing' },
                { label: 'About Us', href: '/#about' },
                { label: 'Gallery', href: '/#gallery' },
                { label: 'Contact', href: '/#contact' },
              ].map(({ label, href }) => (
                <li key={href}>
                  <Link href={href} className="text-brand-muted text-sm hover:text-brand-orange transition-colors flex items-center gap-2 group">
                    <span className="w-1 h-1 bg-brand-orange rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-lg text-white tracking-wider mb-4">CONTACT US</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin size={15} className="text-brand-orange mt-0.5 flex-shrink-0" />
                <span className="text-brand-muted text-sm">Edmonton, Alberta, Canada</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={15} className="text-brand-orange flex-shrink-0" />
                <a href="tel:+17801234567" className="text-brand-muted text-sm hover:text-brand-orange transition-colors">
                  (780) 123-4567
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={15} className="text-brand-orange flex-shrink-0" />
                <a href="mailto:hello@clearoutpro.ca" className="text-brand-muted text-sm hover:text-brand-orange transition-colors">
                  hello@clearoutpro.ca
                </a>
              </li>
            </ul>

            <div className="mt-6 p-3 bg-brand-border/50 rounded-lg border border-brand-border">
              <p className="text-xs text-brand-muted">
                <span className="text-green-400 font-semibold">● Available Today</span>
              </p>
              <p className="text-xs text-brand-muted mt-1">Mon–Sat: 7AM – 8PM</p>
              <p className="text-xs text-brand-muted">Sun: 9AM – 5PM</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-brand-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-brand-muted">
            <div className="flex items-center gap-1">
              <span>© {year} ClearOut Pro. All rights reserved.</span>
            </div>

            {/* MicrOrbit Credit */}
            <div className="flex items-center gap-2">
              <span>A product by</span>
              <span className="font-semibold text-brand-orange tracking-wide">MicrOrbit</span>
              <span className="text-brand-border">|</span>
              <a href="#" className="hover:text-brand-orange transition-colors">Privacy Policy</a>
              <span className="text-brand-border">|</span>
              <a href="#" className="hover:text-brand-orange transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
