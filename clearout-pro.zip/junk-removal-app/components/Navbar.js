'use client';
import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, Truck, LayoutDashboard, Kanban, FileText, DollarSign, Settings } from 'lucide-react';
import clsx from 'clsx';

const navLinks = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/jobs', label: 'Jobs', icon: Kanban },
  { href: '/quotes', label: 'Quotes', icon: FileText },
  { href: '/revenue', label: 'Revenue', icon: DollarSign },
  { href: '/pricing', label: 'Pricing', icon: Settings },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <nav className="bg-brand-card border-b border-brand-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-brand-orange rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <Truck size={16} className="text-white" />
            </div>
            <span className="font-display text-2xl text-white tracking-wide">
              CLEAR<span className="text-brand-orange">OUT</span>
            </span>
            <span className="text-xs text-brand-muted mt-1 hidden sm:block">PRO</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className={clsx(
                  'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200',
                  pathname === href
                    ? 'bg-brand-orange text-white'
                    : 'text-brand-muted hover:text-brand-text hover:bg-white/5'
                )}
              >
                <Icon size={15} />
                {label}
              </Link>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/"
              className="text-sm text-brand-muted hover:text-brand-orange transition-colors"
            >
              View Website
            </Link>
            <Link
              href="/quotes"
              className="btn-primary text-sm py-2 px-4"
            >
              + New Quote
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden text-brand-muted hover:text-white p-2 rounded-lg"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="md:hidden border-t border-brand-border bg-brand-card px-4 py-3 space-y-1">
          {navLinks.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className={clsx(
                'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all',
                pathname === href
                  ? 'bg-brand-orange text-white'
                  : 'text-brand-muted hover:text-brand-text hover:bg-white/5'
              )}
            >
              <Icon size={16} />
              {label}
            </Link>
          ))}
          <div className="pt-2 pb-1">
            <Link
              href="/quotes"
              onClick={() => setOpen(false)}
              className="btn-primary text-sm py-2 px-4 block text-center"
            >
              + New Quote
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
